package hotel_m1;

public class Cargo  {
	String nome;
	
	public Cargo(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}

}
